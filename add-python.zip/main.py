a=2
b=3
print(a+b)